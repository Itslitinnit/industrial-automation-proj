# SortingByHeight

Factory IO sort by height scene is simulated with siemens plc. 

TIA PORTAL V16 is used for programming. Program is written mostly in SCL language.
