# Factory-IO---Sorting-by-Height-Basic-
Factory IO - Sorting by Height solution using different brand of PLC's. Each time a new brand is used, a new directory will be created and uploaded as a solution.

Here is the youtube link of simulation. You can watch how the system works : https://youtu.be/q-8n5OxRMqs . 

TIA PORTAL and twincat 3 is uploaded so far. I used the same algorithm and structure for coding. Two project have minimal differencies. Therefore I shooted only one video instead of shooting each. 

For TIA PORTAL, I uploaded some screenshots from program. To communicate Factory IO and TIA PORTAL, PLC SIM must be running and PLC should be in the run mode. In program, a special FC is used and can be found in the official website of factory IO.

For Twincat 3, Factory IO doesn't support direct connection. But you can configure modbus tcp communication between factory io and twincat 3. If you want to simulate twincat 3 instead of real plc, you first need to install this file "win8settick.bat" under this path "C:\TwinCAT\3.1\System". The file can be located under different path depending on your system. Don't forget to reboot your system after installation. 

